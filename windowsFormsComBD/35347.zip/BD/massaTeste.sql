insert into pessoa values (1, '627.750.999-39', 'Tiago Araújo', '(21) 2772-7090');
insert into pessoa values (2, '266.863.748-14', 'Patrícia Galvão', '(68) 3913-8235');
insert into pessoa values (3, '059.480.317-99', 'Bruno Duarte', '(75) 3681-7139');
insert into pessoa values (4, '115.627.615-28', 'Valentina da Luz', '(83) 2628-8051');
insert into pessoa values (5, '580.482.915-76', 'Vera Aparício', '(91) 3540-5374');
insert into pessoa values (6, '462.511.766-60', 'Otávio Martins', '(43) 3636-4135');
insert into pessoa values (7, '490.706.366-03', 'Marli de Paula', '(63) 3594-3834');
insert into pessoa values (8, '504.574.069-50', 'Bárbara Jesus', '(31) 2801-5842');
insert into pessoa values (9, '118.626.203-69', 'Erick Jesus', '(96) 3918-5124');
insert into pessoa values (10, '444.515.142-40', 'Juliana Rezende', '(82) 3842-0695');

select * from pessoa;