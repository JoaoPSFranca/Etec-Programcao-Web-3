﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MaisCulturaSantos
{
    internal static class Conexao
    {
        public static string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=PetsPessoas";
    }
}
