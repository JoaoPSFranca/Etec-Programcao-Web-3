﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex4_RedeSocial
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dataPostagem = new DateTime(2022,02,22, 14, 24, 35);
            string subtit = "";
            string tit = "";
            bool tituloBool = true;
            bool subtituloBool = true;

            Postagem postagem = new Postagem(dataPostagem, "Comida", "Hoje eu comi um pão");
            
            Console.WriteLine("Postagem: ");
            Console.WriteLine("Data e Hora da Postagem: " + postagem.GetSetDataHora);
            Console.WriteLine("Titulo: " + postagem.GetSetTitulo);
            Console.WriteLine("Subtitulo: " + postagem.GetSetSubtitulo);

            while (tituloBool)
            {
                Console.WriteLine();
                Console.WriteLine("Digite a alteração do titulo: ");
                tit = Console.ReadLine();

                if (postagem.editarTitulo(tit))
                {
                    Console.WriteLine("Titulo alterado para: " + postagem.GetSetTitulo.ToString());
                    postagem.GetSetTitulo = tit;
                    tituloBool = !tituloBool;
                }
                else
                    Console.WriteLine("Digite apenas valores válidos. ");
            }

            while (subtituloBool)
            {
                Console.WriteLine();
                Console.WriteLine("Digite a alteração do Subtítulo: ");
                subtit = Console.ReadLine();

                if (postagem.editarSubtitulo(subtit))
                {
                    postagem.GetSetSubtitulo = subtit;
                    Console.WriteLine("Subtitulo alterado para: " + postagem.GetSetSubtitulo.ToString());
                    subtituloBool = !subtituloBool;
                }
                else
                    Console.WriteLine("Digite apenas valores válidos. ");

            }

            Console.WriteLine();
            Console.WriteLine("Postagem: ");
            Console.WriteLine("Data e Hora da Postagem: " + postagem.GetSetDataHora);
            Console.WriteLine("Titulo: " + postagem.GetSetTitulo);
            Console.WriteLine("Subtitulo: " + postagem.GetSetSubtitulo);

            Console.WriteLine();
            Console.WriteLine("Pressione algo para excluir a Publicação: ");
            Console.ReadKey();
            Console.WriteLine();
            Console.WriteLine(postagem.excluirPublicacao());

            Console.ReadKey();
        }
    }
}
